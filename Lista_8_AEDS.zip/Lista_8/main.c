#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Função da Questão 1
void printrecursivo(int i) {
  printf("%d ", i);
  if (i < 5) {
    printrecursivo(i + 1);
  }
  printf("%d ", i);
}

void Questao1() {
  int i = 1;
  printrecursivo(i);
}

// Função da Questão 2
void printrecursivo2(int a, int b) {
  printf("%d ", a);
  if (a < b) {
    printrecursivo2(a + 1, b);
  }
  printf("%d ", a);
}

void Questao2() {
  int a, b;
  printf("Digite o primeiro e o segundo numero: ");
  scanf("%d %d", &a, &b);
  printrecursivo2(a, b);
}

// Função da Questão 3
int contaString(char str[], int cont) {
  if (str[cont] != '\0') {
    return contaString(str, cont + 1);
  }
  return cont;
}

void Questao3() {
  char str[20];
  int cont = 0, cont2 = 0, resp = 0;

  printf("Digite uma string: ");
  scanf(" %s", str);

  resp = contaString(str, cont);
  printf("\nDe forma recursiva: %d", resp);

  for (int i = 0; str[i] != '\0'; i++) {
    cont2++;
  }
  printf("\nDe forma iterativa: %d", cont2);
}

// Função da Questão 4
void imprimir_reversa(char *str, int tamanho) {
  if (tamanho >= 0) {
    printf("%c", str[tamanho]);
    imprimir_reversa(str, tamanho - 1);
  }
}

void Questao4() {
  char str[50];
  printf("Digite um string: ");
  scanf(" %[^\n]", str);
  int tamanho = strlen(str) - 1;
  imprimir_reversa(str, tamanho);
}

// Função da Questão 5
void inverte(int vetor[], FILE *arq, int n) {
  if (n >= 0) {
    fprintf(arq, "%d ", vetor[n]);
    inverte(vetor, arq, n - 1);
  }
}

void Questao5() {
  int n;
  printf("Digite o tamanho do vetor: ");
  scanf("%d", &n);

  int *vetor = (int *)malloc(n * sizeof(int));
  if (!vetor) {
    printf("Erro ao alocar memória!\n");
    return;
  }

  printf("\nDigite o conteudo do vetor: ");
  for (int i = 0; i < n; i++) {
    scanf("%d", &vetor[i]);
  }

  FILE *arq = fopen("saida.txt", "w");
  if (arq != NULL) {
    inverte(vetor, arq, n - 1);
    fclose(arq);
  } else {
    printf("Erro ao abrir o arquivo!\n");
  }

  free(vetor);
}

// Função da Questão 6
int divisao(int numerador, int denominador) {
  if (numerador < denominador) {
    return 0;
  } else {
    return 1 + divisao(numerador - denominador, denominador);
  }
}

void Questao6() {
  int numerador, denominador;
  printf("Digite o numerador e o denominador: ");
  scanf("%d %d", &numerador, &denominador);
  printf("%d", divisao(numerador, denominador));
}

// Função da Questão 7
float soma(int n) {
  if (n == 1) {
    return 1;
  } else {
    return 1.0 / n + soma(n - 1);
  }
}

void Questao7() {
  int n;
  do {
    printf("Digite o valor de n: ");
    scanf("%d", &n);
  } while (n <= 0);
  printf("\nA soma eh: %.2f", soma(n));
}

// Função da Questão 8
int lucas(int n) {
  if (n == 0) {
    return 2;
  } else if (n == 1) {
    return 1;
  } else {
    return lucas(n - 1) + lucas(n - 2);
  }
}

void Questao8() {
  int n, resp = 0;
  do {
    printf("\nDigite um valor para n: ");
    scanf("%d", &n);
  } while (n <= 0);
  resp = lucas(n);
  printf("%d", resp);
}

int main() {
  int escolha;
  do {
    printf("\n\nLista 8:\n");
    printf("1 - Questão A1\n");
    printf("2 - Questão A2\n");
    printf("3 - Questão A3\n");
    printf("4 - Questão A4\n");
    printf("5 - Questão A5\n");
    printf("6 - Questão A6\n");
    printf("7 - Questão A7\n");
    printf("8 - Questão A8\n");
    printf("0 - Sair\n");
    printf("Escolha: ");
    scanf("%d", &escolha);

    switch (escolha) {

    case 1:
      Questao1();
      break;

    case 2:
      Questao2();
      break;

    case 3:
      Questao3();
      break;

    case 4:
      Questao4();
      break;

    case 5:
      Questao5();
      break;

    case 6:
      Questao6();
      break;

    case 7:
      Questao7();
      break;

    case 8:
      Questao8();
      break;

    case 0:
      printf("Programa Encerrado\n");
      break;

    default:
      printf("Opção inválida!\n");
      break;
    }
  } while (escolha != 0);

  return 0;
}
